//#include"LexicalAnalysis.h"
//#include"Shared.h"
//
//using namespace std;
//
////��������
//void enter(int kind);
//int position(char* id);
//void constdeclaration();
//void vardeclaration(void);
//void gen(int x, int y, int z);
//void factor();
//void term();
//void expression();
//void condition();
//void statement();
////void printCode(int from, int to);
//int base(int stack[], int currentLevel, int levelDiff);
//void interpret();
//void block();
//void printCodeToFile(const char* filename, int from, int to);